WORKOUT WARRIOR RPG — ANDROID HOME-SCREEN APP

FILES
- index.html: the game
- manifest.json: app name, icon, and install settings
- service-worker.js: offline caching
- icons/icon-192.png and icons/icon-512.png: app icons

PUBLISH WITH GITHUB PAGES
1. Sign in to https://github.com in your browser and create a new PUBLIC repository, e.g. workout-warrior-rpg.
2. Upload all files and folders from this package to the repository root. The root should contain index.html, manifest.json, service-worker.js, and the icons folder.
3. In the repository, open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish. Your address will look like:
   https://YOUR-USERNAME.github.io/workout-warrior-rpg/
   Use the exact URL shown in Settings → Pages.

INSTALL ON ANDROID
1. Open the published HTTPS URL in Chrome on your Android phone.
2. Wait for the page to finish loading.
3. Tap Chrome's ⋮ menu.
4. Tap "Install app" or "Add to Home screen" (wording varies).
5. Confirm. Open Workout Warrior RPG from the new home-screen icon.

NOTES
- Keep the repository public for free GitHub Pages hosting.
- Do not open index.html directly from Downloads to install it; PWA installation needs an HTTPS website.
- XP is stored in the browser on this device. Clearing site data or using a different browser/device may reset or separate progress.
- If you change files later, refresh the website. You may need to close and reopen the app to get an updated cached version.
